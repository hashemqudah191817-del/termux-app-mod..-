     import android.os.Bundle;
     import android.view.Menu;
     import android.view.MenuItem;
     import androidx.appcompat.app.AppCompatActivity;

     public class MainActivity extends AppCompatActivity {
         @Override
         protected void onCreate(Bundle savedInstanceState) {
             super.onCreate(savedInstanceState);
             setContentView(R.layout.activity_main);
         }

         @Override
         public boolean onCreateOptionsMenu(Menu menu) {
             getMenuInflater().inflate(R.menu.menu_layout, menu);
             return true;
         }

         @Override
         public boolean onOptionsItemSelected(MenuItem item) {
             if (item.getItemId() == R.id.im_bot) {
                 // قم بتفعيل خيار IM Bot
                 // يمكنك إضافة الكود هنا لفتح فري فاير أو أي إجراء آخر
                 openFreeFire();
                 return true;
             }
             return super.onOptionsItemSelected(item);
         }

         private void openFreeFire() {
             // كود لفتح فري فاير
             // يمكنك استخدام Intent لفتح التطبيق
             Intent intent = new Intent();
             intent.setPackage("com.dts.freefireth");
             startActivity(intent);
         }
     }
     
